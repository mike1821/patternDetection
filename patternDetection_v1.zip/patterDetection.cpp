#include "patternDetection.h"
#include "definitions.h"
#include "MatToQImage.h"

#include <iostream>
#include <vector>
#include <algorithm>
#include <QDir>
using namespace cv;
using namespace std;

struct rangeFinder {
        rangeFinder(int xmin, int xmax, int ymin, int ymax)
        : m_xmin(xmin), m_xmax(xmax), m_ymin(ymin), m_ymax(ymax)
        {}

        bool operator()(const Point &v) {
                return ( (v.x <= m_xmax && v.x >= m_xmin) &&  (v.y <= m_ymax && v.y >= m_ymin) ) ? true : false;
        }

        int m_xmin, m_xmax, m_ymin, m_ymax;
};

bool comparator( const int& a ,const int& b ){ return b < a; }

patternDetection::patternDetection(){
}

patternDetection::~patternDetection(){

}

int patternDetection::processCoupon(QString qsImage, int iIndex)
{
    vector<Point> boxCenters;
    vector<vector <Point> > RowsCols;
    double duration,total;
    QString qsImageOnDisk = qsImage.arg(iIndex);

    Initialize();
    //return 0;

#ifdef WINDOWS
    char path[]="C:\\Users\\user\\AppData\\Local\\VirtualStore\\";
#else
    char path[]="/home/mike/Dropbox/Programming/patternDetection/lib/";
#endif
    char filename[512];

    std::cout << "Starting Designated execution" << std::endl;


//    sprintf(filename, "%scamshot-dev-0-00%03d.jpg",path,imageCounter);

//    std::cout << "Processing image: " << filename << std::endl;

    std::cout << "Processing image: " << qPrintable(qsImageOnDisk) << std::endl;
    Mat img_scene=splitChannels(qPrintable(qsImageOnDisk));
    //Mat img_scene = imread( filename, CV_LOAD_IMAGE_GRAYSCALE );
    Mat img_sceneA = img_scene.clone();

    total=duration = static_cast<double>(cv::getTickCount());
    int ret=detectLogo(img_sceneA);
    duration = ((double)getTickCount() - duration)*1000./getTickFrequency();
    std::cout << "Logo detection time: " << duration << std::endl;

    switch (ret)
    {
        case 1:
          std::cout << "Coupon is a POWERBALL" << std::endl;
          break;
        case 2:
          std::cout << "Coupon is a  EASY5" << std::endl;
          break;
        case 3:
          std::cout << "Coupon is a  PICK4" << std::endl;
          break;
        case 4:
          std::cout << "Coupon is a  LOTTO" << std::endl;
          break;
        default:
          std::cout << "Unknown coupon" << std::endl;
          return -1;
    }

    //Required for relatively skewed images because ROI cropping crashes
    Mat imageAreas = /*deskewImage(img_scene);*/img_scene.clone();
    Mat imageBoxes = /*deskewImage(img_scene);*/img_scene.clone();

    duration = static_cast<double>(cv::getTickCount());
    boxCenters = detectBoxes(imageAreas,RowsCols); //Detect boxes on the cropped image

    duration = ((double)getTickCount() - duration)*1000./getTickFrequency();
    std::cout << "Boxes detection time: " << duration << std::endl;

    duration = static_cast<double>(cv::getTickCount());
    sortBoxes(boxCenters); //sort boxes based on logo bottom left corner distance
    duration = ((double)getTickCount() - duration)*1000./getTickFrequency();
    std::cout << "Boxes sorting time: " << duration << std::endl;

    duration = static_cast<double>(cv::getTickCount());
    vector<Point> detectedMarks = ROIaveragePixelValue(imageBoxes,boxCenters,RowsCols); //Detect avgPixel value on each box

    std::cout << "Marked boxes found @" << std::endl;
    for(int i=0;i<detectedMarks.size();i++)
        std::cout << i << ": " << detectedMarks[i].x << "," << detectedMarks[i].y << std::endl;
    duration = ((double)getTickCount() - duration)*1000./getTickFrequency();
    std::cout << "Avg pixel value time: " << duration << std::endl;

    total = ((double)getTickCount() - total)*1000./getTickFrequency();
    std::cout << "\nTOTAL processing time: " << total << std::endl;

    return 0;
}

double patternDetection::calculateAngle( Point pt1, Point pt2, Point pt0 )
{
    // Finds a cosine of angle between vectors
    // from pt0->pt1 and from pt0->pt2
    double dx1 = pt1.x - pt0.x;
    double dy1 = pt1.y - pt0.y;
    double dx2 = pt2.x - pt0.x;
    double dy2 = pt2.y - pt0.y;
    return (dx1*dx2 + dy1*dy2)/sqrt((dx1*dx1 + dy1*dy1)*(dx2*dx2 + dy2*dy2) + 1e-10);
}

vector<vector<Point> > patternDetection::detectAreas( Mat &image)
{
    vector<vector<Point> > areas;
    areas.clear();

    thresh=30;
    Mat image2 = image.clone();
    //Mat image1 = imread(input);
    Mat pyr, timg;
    vector<vector<Point> > contours;

    // Down-scale and upscale the image to filter out the noise
    pyrDown(image, pyr, Size(image.cols/2, image.rows/2));
    pyrUp(pyr, timg, image.size());

    // Convert to greyscale and then to binary image using Canny
    //cv::cvtColor(image, gray, CV_BGR2GRAY);

    cv::Mat bw;
    //cv::blur( gray, bw, Size(3,3) );
    //cv::Canny(gray, bw, 0, 50, 3);
    cv::Size size(3,3);
    cv::GaussianBlur(image,image,size,0);
    adaptiveThreshold(image, image,255,CV_ADAPTIVE_THRESH_MEAN_C, CV_THRESH_BINARY,75,10);
    cv::bitwise_not(image, image);

#ifdef DEBUG_IMAGES
    imshow("SquareDetection - Binarized image", image);
    waitKey();
#endif

    // Find contours and store them all as a list
    findContours(image, contours, CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE);

    vector<Point> approx;

    // Check detected contour for meeting the square specifications
#ifdef DEEP_DEBUG
    std::cout<< "Contours size: " << contours.size() << std::endl;
#endif
    for( size_t i = 0; i < contours.size(); i++ )
    {
          // approximate contour with accuracy proportional
          // to the contour perimeter
          approx.clear();
          approxPolyDP(Mat(contours[i]), approx, arcLength(Mat(contours[i]), true)*0.02, true);

          // square contours should have 4 vertices after approximation
          // and relatively large area
          if( approx.size() == 4 && fabs(contourArea(Mat(approx))) > AREA_MIN_SIZE && fabs(contourArea(Mat(approx))) < AREA_MAX_SIZE && isContourConvex(Mat(approx)) )
          {
                double maxCosine = 0;

                for( int j = 2; j < 5; j++ ){
                    // find the maximum cosine of the angle between joint edges
                    double cosine = fabs(calculateAngle(approx[j%4], approx[j-2], approx[j-1]));
                    maxCosine = MAX(maxCosine, cosine);
                }

                // if cosines of all angles are small
                // (all angles are ~90 degree) then write quandrange
                // vertices to resultant sequence
                if( maxCosine < 0.3 ){
                    areas.push_back(approx);
#ifdef DEEP_DEBUG
                    for (int x=0;x<4;x++)
                        std::cout << "approx: " << approx[x].x << " - " << approx[x].y << std::endl;
                    std::cout<<std::endl;
#endif
                }
          }
    }

#ifdef DEBUG
    std::cout << "size (areas): " << areas.size() << std::endl;
#endif
    //Mat image2 = imread(input, 1);

    //draw the detected areas
    for( size_t i = 0; i < areas.size(); i++ )
    {
        const Point* p = &areas[i][0];
        int n = (int)areas[i].size();
        std::cout << "Area[" << i << "]: " << "size: " << contourArea(areas[i],false) << std::endl;
        polylines(image2, &p, &n, 1, true, Scalar(255,255,255), 1, CV_8U);
    }

#ifdef DEBUG_IMAGES
    imshow("SquareDetection - Detected areas", image2);
    waitKey();
#endif

    if(areas.size()==0)
        return areas;

    for(auto &vp : areas)
       blowMe(vp);

    //we need to short areas based on logo detection coordinates
    if(logoDirection==RIGHT){
        vector<Point> local;
        for( size_t i = 0; i < areas.size()-1; i++ ){
            for (size_t j=i+1;j< areas.size(); j++)
                if( (areas[i][0].x ) < (areas[j][0].x) ){
                    local=areas[i];
                    areas[i]=areas[j];
                    areas[j]=local;
                }
        }
    }
    else if(logoDirection==LEFT){
        vector<Point> local;
        for( size_t i = 0; i > areas.size()-1; i++ ){
            for (size_t j=i+1;j< areas.size(); j++)
                if( (areas[i][0].x ) < (areas[j][0].x) ){
                    local=areas[i];
                    areas[i]=areas[j];
                    areas[j]=local;
                }
        }
    }

#ifdef DEEP_DEBUG
    for (unsigned int x=0;x<areas.size();x++){
        for(int i=0; i<4;i++)
            std::cout << "Area "<< x << " :" << areas[x][i].x << " - " << areas[x][i].y << std::endl;
        std::cout<<std::endl;
    }
#endif

    return areas;
}


vector<Point> patternDetection::detectBoxes( Mat &image, vector<vector <Point> > &RowsCols)
{
    vector<vector<Point> > boxes;
    vector<Point> interpolated;
    boxes.clear();

    thresh=30;
#ifdef DEBUG_IMAGES
    Mat image2 = image.clone();
    Mat image3 = image.clone();
#endif


    Mat image4 = image.clone();
    Mat image5 = image.clone();

    vector<vector<Point> > contours;

    Fiducial.x=0;
    Fiducial.y=0;

    //fastNlMeansDenoising(image,image);
#ifdef DEBUG_IMAGES
    imshow("Boxes original  image", image);
    waitKey();
#endif

    Mat frame = image.clone();
    cv::GaussianBlur(frame, image, cv::Size(0,0), 3);
    cv::addWeighted(frame, 1.5, image, -0.5, 0, image);

    adaptiveThreshold(image, image,255,ADAPTIVE_THRESH_GAUSSIAN_C, CV_THRESH_BINARY,9,5);
    //cv::bitwise_not(image, image);

    // flood fill with white
    //cv::floodFill(image, cv::Point(140,160), 255, (cv::Rect*)0, cv::Scalar(), 4);

//    int erode_size = 1;
//    int erode_type=MORPH_RECT;
//    Mat element = getStructuringElement( erode_type,
//                                           Size( erode_size + 1, erode_size+1 ),
//                                           Point( erode_size, erode_size ) );
//    erode(image,image,element,Point(-1,-1),2);

#ifdef DEBUG_IMAGES
    imshow("Boxes filtered  image", image);
    waitKey();
#endif


    findContours(image, contours, CV_RETR_LIST, CV_CHAIN_APPROX_TC89_KCOS);

#ifdef DEBUG_IMAGES
    //draw the detected contours
    for( size_t i = 0; i < contours.size(); i++ )
    {
        const Point* p = &contours[i][0];
        int n = (int)contours[i].size();
       // std::cout << "Box[" << i << "]: " << "size: " << contourArea(boxes[i],false) << std::endl;
        polylines(image3, &p, &n, 1, true, Scalar(255,255,255), 1, CV_8U);
    }
    imshow("SquareDetection - Detected contours", image3);
    waitKey();
#endif

    int maxArea = 0;
    int index = -1;
    vector<Point> approx;

#ifdef DEEP_DEBUG
    std::cout<< "Contours size (boxes): " << contours.size() << std::endl;
#endif
    for( size_t i = 0; i < contours.size(); i++ )
    {
          approx.clear();
          approxPolyDP(Mat(contours[i]), approx, arcLength(Mat(contours[i]), true)*0.04, true );

          if( approx.size() == 4 && fabs(contourArea(Mat(approx))) > BOX_MIN_SIZE
                                 && fabs(contourArea(Mat(approx))) < BOX_MAX_SIZE
                                 && isContourConvex(Mat(approx)) )
          {
                double maxCosine = 0;

                for( int j = 2; j < 5; j++ ){
                    // find the maximum cosine of the angle between joint edges
                    double cosine = fabs(calculateAngle(approx[j%4], approx[j-2], approx[j-1]));
                    maxCosine = MAX(maxCosine, cosine);
                }

                if( maxCosine < 0.3 ){
                    boxes.push_back(approx);
                    int area=contourArea(Mat(approx));
                    if(area>maxArea){
                        maxArea=area;
                        Fiducial=detectCenters(contours[i]);
                    }
                }
          }

          //detect circles
//          if(approx.size() > 4 && fabs(contourArea(Mat(approx))) > BOX_MIN_SIZE
//                               && fabs(contourArea(Mat(approx))) < BOX_MAX_SIZE
//                               && isContourConvex(Mat(approx)))
//          {
//              double area = cv::contourArea(contours[i]);
//              cv::Rect r = cv::boundingRect(contours[i]);
//              int radius = r.width / 2;

//	      if (std::abs(1 - ((double)r.width / r.height)) <= 0.2 &&
//		  std::abs(1 - (area / (CV_PI * std::pow(radius, 2)))) <= 0.2){
//		  Fiducial.x=contours[i][0].x;
//		  Fiducial.y=contours[i][0].y;
//		  std::cout << "FIDUCIAL located at: " << Fiducial.x << "-" << Fiducial.y << std::endl;
//	      }

//          }
    }

    std::cout << "FIDUCIAL located at: " << Fiducial.x << "-" << Fiducial.y << std::endl;

#ifdef DEBUG
    std::cout << "size (boxes): " << boxes.size() << std::endl;
#endif

    if(boxes.size()<1)
        return interpolated;

    for(auto &vp : boxes)
       blowMe(vp);

#ifdef DEBUG_IMAGES
    //draw the detected boxes
    for( size_t i = 0; i < boxes.size(); i++ )
    {
        const Point* p = &boxes[i][0];
        int n = (int)boxes[i].size();
       // std::cout << "Box[" << i << "]: " << "size: " << contourArea(boxes[i],false) << std::endl;
        polylines(image2, &p, &n, 1, true, Scalar(255,255,255), 1, CV_8U);
    }

    imshow("SquareDetection - Detected boxes", image2);
    waitKey();
#endif

//Remove duplicates
    int offset=6;
    int removals=0;
    for(uint i = 0; i < boxes.size(); i++)
    {
        int currentx = boxes[i][0].x;
        int currenty = boxes[i][0].y;

        for(uint j = i+1; j < boxes.size(); j++)
        {
            int tempx = boxes[j][0].x;
            int tempy = boxes[j][0].y;

            if( abs(currentx - tempx)<=offset && abs(currenty - tempy)<=offset )
            {
                if(currentx>=tempx){
                    vector<vector<Point> >::iterator iter = boxes.begin() + j;
                    boxes.erase(iter);
                }
                else{
                    vector<vector<Point> >::iterator iter = boxes.begin() + i;
                    boxes.erase(iter);
                }
                j--;
                ++removals;
            }
        }
    }

    std::cout << "Removals: " << removals << " Remaining: " << boxes.size() << std::endl;

#ifdef DEEP_DEBUG
    for (unsigned int x=0;x<boxes.size();x++){
        for(int i=0; i<4;i++)
            std::cout << "Area "<< x << " :" << boxes[x][0].x << " - " << boxes[x][0].y << std::endl;
        std::cout<<std::endl;
    }
#endif

    //Search for any missing boxes and add them
    interpolated = interpolateBoxes(loadedBoxes, boxes);

    //we need to short boxes based on x and y coordinate and coupon orientation
    if(logoDirection==RIGHT){
        Point local1;
        for( size_t i = 0; i < interpolated.size()-1; i++ ){
            for (size_t j=i+1;j< interpolated.size(); j++)
                if( (interpolated[i].y < interpolated[j].y)  ){
                    local1=interpolated[i];
                    interpolated[i]=interpolated[j];
                    interpolated[j]=local1;
                }
        }

        Point local2;
        for( size_t i = 0; i < interpolated.size()-1; i++ ){
            for (size_t j=i+1;j< interpolated.size(); j++)
                if( (interpolated[i].x <= interpolated[j].x)  ){
                    local2=interpolated[i];
                    interpolated[i]=interpolated[j];
                    interpolated[j]=local2;
                }
        }
    }
    else if(logoDirection==LEFT){
        Point local1;
        for( size_t i = 0; i > interpolated.size()-1; i++ ){
            for (size_t j=i+1;j< interpolated.size(); j++)
                if( (interpolated[i].y > interpolated[j].y) ){
                    local1=interpolated[i];
                    interpolated[i]=interpolated[j];
                    interpolated[j]=local1;
                }
        }

        Point local2;
        for( size_t i = 0; i < interpolated.size()-1; i++ ){
            for (size_t j=i+1;j< interpolated.size(); j++)
                if( (interpolated[i].x >= interpolated[j].x)  ){
                    local2=interpolated[i];
                    interpolated[i]=interpolated[j];
                    interpolated[j]=local2;
                }
        }

    }

#ifdef DEBUG_IMAGES
    std::cout << "Detected and Interpolated boxes" << std::endl;

    for(size_t i=0; i<interpolated.size();i++){
        std::cout << i << ". " << interpolated[i].x << "-" << interpolated[i].y << std::endl;
        circle(image4,interpolated[i],1,Scalar(255,255,255),8);
    }

    cv::namedWindow("Detected boxes");
    cv::imshow("Detected boxes",image4);
    waitKey();
#endif

    // Sort by row and column the detected boxes
//    vector <Point> curRow;
//    offset=5;

//    for (uint i=0;i<interpolated.size();i++){

//        if( abs(interpolated[i].x-interpolated[i+1].x)<=offset)
//            curRow.push_back(interpolated[i]);
//        else{
//            curRow.push_back(interpolated[i]);
//            RowsCols.push_back(curRow);
//            curRow.clear();
//        }
//    }

#ifdef DEBUG
    std::cout << "Rows detected " << RowsCols.size() << std::endl;
    for (size_t i=1; i<RowsCols.size();i++){
        std::cout << "Row " << i << std::endl;
        for (size_t j=0; j<RowsCols[i].size(); j++)
              std::cout << RowsCols[i][j].x << "-" << RowsCols[i][j].y << std::endl;
    }
#endif

    return interpolated;
}

vector<Point> patternDetection::interpolateBoxes( vector<Point> expectedCenters, vector<vector<Point> > foundBoxes)
{

    //We need to get box centers at first
    vector<Point> boxCenters;

    for(auto &vp : foundBoxes)
        boxCenters.push_back(detectCenters(vp));

//    missingCenters=boxCenters;

//    //reference boxes based on located FIDUCIAL
//    for(size_t i=0; i<boxCenters.size();i++)
//    {
//        if(boxCenters[i]==Fiducial)
//            continue; //skip the fiducial itslef

//        std::cout << i << ". " << expectedCenters[i].x << " - " << expectedCenters[i].y << "    ";

//        boxCenters[i].x=abs(boxCenters[i].x - Fiducial.x);
//        boxCenters[i].y=abs(boxCenters[i].y - Fiducial.y);

//        std::cout << boxCenters[i].x << " - " << boxCenters[i].y << std::endl;
//    }

//    for(size_t i=0;i<expectedCenters.size();i++)
//    {
//        Point index=expectedCenters[i];
//        if( std::find_if(boxCenters.begin(),boxCenters.end(),rangeFinder(index.x-20,index.x+20,index.y-20,index.y+20))==boxCenters.end() ){
//            std::cout << "Missing: " << expectedCenters[i].x << "-" << expectedCenters[i].y << std::endl;
//            boxCenters.push_back(expectedCenters[i]);
//        }
//    }

    //temp for loop until coupon definition file is ready
//    for(size_t i=0;i<boxCenters.size();i++)
//        detectedCenters.push_back(boxCenters[i]);

    return boxCenters;

}

void patternDetection::sortBoxes( vector<Point> &boxes)
{
    //sort
    for(unsigned int i=0;i<boxes.size();i++)
        for(unsigned int j=i+1; j < boxes.size();j++)
            if(compare(boxes[i], boxes[j]))
                std::swap(boxes[i], boxes[j]);

#ifdef DEBUG
    for (unsigned int x=0;x<boxes.size();x++){
            std::cout << "Box (sorted) "<< x << " : " << boxes[x].x << "-" << boxes[x].y << ", " << distance ( (cv::Point) (boxes[x]))  << std::endl;
        std::cout<<std::endl;
    }
#endif
}

bool patternDetection::compare(Point i, Point j)
{
    return distance(i) > distance(j);
}

int patternDetection::detectLogo(Mat img_scene)
{

#ifdef WINDOWS
    static const char* logos[] = { "C:\\power_ball2.png",0};
#else
    static char* logos[] = { "./logos/power_ball2.png" ,0};
#endif

    if( !img_scene.data ){
        std::cout<< " (!) Error reading images " << std::endl;
        return -1;
    }

    //Detect the keypoints using SURF Detector
    int minHessian = 400,couponId=0, i=0;
    std::vector<KeyPoint> keypoints_object, keypoints_scene;
    Mat descriptors_object, descriptors_scene;

    for(i=0;logos[i]!=0;i++){
            //Load next logo image
            //Mat img_object = imread( logos[i], CV_LOAD_IMAGE_GRAYSCALE );

#ifdef WINDOWS
            //cv:Ptr<cv::BRISK> detector = cv::BRISK::create();
            cv::FeatureDetector * detector = new cv::SIFT();
            detector->detect( img_object, keypoints_object );
            detector->detect( img_scene, keypoints_scene );
#else
            SurfFeatureDetector detector( minHessian );
            detector.detect( img_object, keypoints_object );
            detector.detect( img_scene, keypoints_scene );
#endif


#ifdef WINDOWS
            cv::DescriptorExtractor * extractor = new cv::SIFT;
//            cv::Ptr<cv::BRISK> extractor  = cv::BRISK::create();

            extractor->compute(img_object, keypoints_object, descriptors_object);
            extractor->compute(img_scene, keypoints_scene, descriptors_scene);
#else
            SurfDescriptorExtractor extractor;
            extractor.compute(img_object, keypoints_object, descriptors_object);
            extractor.compute(img_scene, keypoints_scene, descriptors_scene);
#endif

            // Draw keypoints
            Mat img_keypoints_object; Mat img_keypoints_scene;

            drawKeypoints( img_object, keypoints_object, img_keypoints_object, Scalar::all(-1), DrawMatchesFlags::DEFAULT );
            drawKeypoints( img_scene, keypoints_scene, img_keypoints_scene, Scalar::all(-1), DrawMatchesFlags::DEFAULT );

            // Show detected (drawn) keypoints
#ifdef DEBUG_IMAGES
            imshow("Keypoints 1", img_keypoints_object );
            imshow("Keypoints 2", img_keypoints_scene );
            waitKey(0);
#endif
            // BruteForceMatcher<L2<float> > matcher;
            FlannBasedMatcher matcher;
            vector<DMatch> matches;

            matcher.match(descriptors_object, descriptors_scene, matches);
            std::cout << "Matches: " << matches.size() << std::endl;

            double max_dist = 0; double min_dist = 100;

            // Quick calculation of max and min distances between keypoints
            for(unsigned int i = 0; i < matches.size(); i++ )
            {
                double dist = matches[i].distance;
                if( dist < min_dist && dist>0.0)
                     min_dist = dist;
                if( dist > max_dist )
                     max_dist = dist;
            }

            // Draw only "good" matches (i.e. whose distance is less than 3*min_dist )
            std::vector< DMatch > good_matches;

            for( int i = 0; i < descriptors_object.rows; i++ )
                if( matches[i].distance < 5*min_dist )
                    good_matches.push_back( matches[i]);

            std::cout << "Good mathces= " << good_matches.size() << std::endl;

            Mat img_matches;
            drawMatches( img_object, keypoints_object, img_scene, keypoints_scene,
                         good_matches, img_matches, Scalar::all(-1), Scalar::all(-1),
                         vector<char>(), DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS );

            // Localize the object
            std::vector<Point2f> object;
            std::vector<Point2f> scene;

            for( unsigned int i = 0; i < good_matches.size(); i++ )
            {
                //Get the keypoints from the good matches
                object.push_back( keypoints_object[ good_matches[i].queryIdx ].pt );
                scene.push_back( keypoints_scene[ good_matches[i].trainIdx ].pt );
            }

            Mat H = findHomography( object, scene, CV_RANSAC );

            // Get the corners from the image_1 ( the object to be "detected" )
            std::vector<Point2f> obj_corners(4);
            obj_corners[0] = cvPoint(0,0);
            obj_corners[1] = cvPoint( img_object.cols, 0 );
            obj_corners[2] = cvPoint( img_object.cols, img_object.rows );
            obj_corners[3] = cvPoint( 0, img_object.rows );

#ifdef DEBUG
            for(unsigned int i=0; i<obj_corners.size();i++)
                std::cout << "obj_corners[" << i << "]: " << obj_corners[i] << std::endl;
#endif

            std::vector<Point2f> scene_corners(4);
            perspectiveTransform( obj_corners, scene_corners, H);

            // Draw lines between the corners (the mapped object in the scene - image_2 )
            line( img_matches, scene_corners[0] + Point2f( img_object.cols, 0), scene_corners[1] + Point2f( img_object.cols, 0), Scalar(0, 255, 0), 4 );
            line( img_matches, scene_corners[1] + Point2f( img_object.cols, 0), scene_corners[2] + Point2f( img_object.cols, 0), Scalar( 0, 255, 0), 4 );
            line( img_matches, scene_corners[2] + Point2f( img_object.cols, 0), scene_corners[3] + Point2f( img_object.cols, 0), Scalar( 0, 255, 0), 4 );
            line( img_matches, scene_corners[3] + Point2f( img_object.cols, 0), scene_corners[0] + Point2f( img_object.cols, 0), Scalar( 0, 255, 0), 4 );

            //calculate object area
            float obj_area = abs((obj_corners[0].x - obj_corners[1].x)) * (abs(obj_corners[1].y - obj_corners[2].y));
            std::cout << "obj_area = " << obj_area << std::endl;
            float scene_area=0;

#ifdef DEBUG
            for(unsigned int i=0; i<scene_corners.size();i++)
                std::cout << "scene_corner[" << i << "]: " << scene_corners[i] << std::endl;
#endif

            // Given that our logo is in upright position scene_corner[0] will always
            // be the top left corner of the logo.
            if(scene_corners[0].x>IMG_HALF){
                logoDirection=RIGHT;
                std::cout << "Coupon is landscape facing right" << std::endl;
                //caluclate scene area
                scene_area = abs(scene_corners[1].x - scene_corners[2].x) * abs(scene_corners[0].y - scene_corners[1].y);
                std::cout << "scene_area = " << scene_area << std::endl;
            }
            else if(scene_corners[0].x<=IMG_HALF){
                logoDirection=LEFT;
                std::cout << "Coupon is landscape facing left" << std::endl;
                scene_area = abs(scene_corners[1].x - scene_corners[2].x) * abs(scene_corners[0].y - scene_corners[1].y);
                std::cout << "scene_area = " << scene_area << std::endl;
            }

            if(abs(obj_area - scene_area) > AREA_SIZE_TOLERANCE){
                std::cout << "Invalid area detection" << std::endl;
                couponId=0;
            }
            else{
                couponId=i+1;

#ifdef DEBUG_IMAGES
                // Show detected matches
                imshow( "Good Matches & Object detection", img_matches );
                waitKey(0);
#endif

                Xa = scene_corners[0].x;
                Ya = scene_corners[0].y;
                Xb = scene_corners[3].x;
                Yb = scene_corners[3].y;

                break;
            }

            keypoints_object.clear();
            keypoints_scene.clear();
            scene_corners.clear();
            obj_corners.clear();
            matches.clear();
            good_matches.clear();
            object.clear();
            scene.clear();
    }

    return couponId;
}

vector<Point> patternDetection::ROIaveragePixelValue(cv::Mat &areaROI,  vector<Point> boxCenters, vector<vector <Point> > RowsCols)
{

    int avgPixelValue=0, avgPixel=0;
    vector<Point> markedBoxes;

    Mat imageDisp = areaROI.clone();
    Mat imageOut  = areaROI.clone();
    stringstream marks;
    string detectedMarks;

#ifdef DEBUG_IMAGES
    cv::namedWindow("boxesROI original image");
    cv::imshow("boxesROI original image",areaROI);
    waitKey();
#endif

//    fastNlMeansDenoising(areaROI,areaROI);

//    cv::GaussianBlur(areaROI,areaROI,size,0);
//    Mat frame = areaROI.clone();
//    cv::GaussianBlur(frame, areaROI, cv::Size(0, 0), 3);
//    cv::addWeighted(frame, 1.5, areaROI, -0.5, 0, areaROI);

    cv::GaussianBlur(areaROI, areaROI, cv::Size(3, 3), 0); //it does not make any difference
    adaptiveThreshold(areaROI, areaROI,255,CV_ADAPTIVE_THRESH_MEAN_C, CV_THRESH_BINARY,75,10);
    cv::bitwise_not(areaROI, areaROI);



//    cv::Size size(3,3);
//    cv::GaussianBlur(areaROI,areaROI,size,0);

//    adaptiveThreshold(areaROI, areaROI,255,ADAPTIVE_THRESH_GAUSSIAN_C, CV_THRESH_BINARY,21,5);
////  cv::bitwise_not(areaROI, areaROI);
//    equalizeHist(areaROI, areaROI);

#ifdef DEBUG_IMAGES
    cv::namedWindow("boxesROI filtered image");
    cv::imshow("boxesROI filtered image",areaROI);
    waitKey();
#endif

    if(!areaROI.data){
        std::cout << "Failed to load ROI of image" << std::endl;
        return markedBoxes;
    }

#ifdef DEEP_DEBUG
    for (unsigned int x=0;x<boxCenters.size();x++)
        std::cout << "Area (Sorted)  "<< x << " :" << boxCenters[x].x << " - " << boxCenters[x].y << std::endl;

#endif

    //Mat betROI = areaROI (cv::Rect(210,40,10,20)); //empty point
    for (uint i=0; i<boxCenters.size();i++)
    //for (size_t i=1; i<RowsCols.size();i++)
    {
        avgPixelValue=0;
        //std::cout << "Processing: " << boxAreas[i][0].x << " - "<< boxAreas[i][0].y << std::endl;
        //for (size_t j=1; j<RowsCols[i].size(); j++){

            //Mat betROI = areaROI (cv::Rect(RowsCols[i][j].x-6,RowsCols[i][j].y-10,12,20)); //filled point
            Mat betROI = areaROI (cv::Rect(boxCenters[i].x-6,boxCenters[i].y-10,12,20)); //filled point
//          cv::namedWindow("ROI image");
//          cv::imshow("ROI image",betROI);
//          waitKey();

            double avgPixel =(double)countNonZero(betROI)/(betROI.size().width*betROI.size().height);

            if(avgPixel>=0.25){
#ifdef DEBUG
                std::cout << "AVG = " << avgPixel << "@(" << i+1 << "," << j+1 << ")" << std::endl;
#endif
                //marks << i+1 << "," << j+1 << " ";
                //detectedMarks+=" ";

                //markedBoxes.push_back(RowsCols[i][j]);
                markedBoxes.push_back(boxCenters[i]);
            }
#ifdef DEBUG
            else
                std::cout << "APV " << avgPixel << " (" << boxCenters[i].x << "," << boxCenters[i].y << ")" << std::endl;
#endif
        //}
    }

    //detectedMarks = marks.str();
    //std::cout << "Detected Marks = " << detectedMarks;

//    int offset=6;
//    int removals=0;
//    for(int i = 0; i < markedBoxes.size(); i++)
//    {
//        int currentx = markedBoxes[i].x;
//        int currenty = markedBoxes[i].y;

//        for(int j = i+1; j < markedBoxes.size(); j++)
//        {
//            int tempx = markedBoxes[j].x;
//            int tempy = markedBoxes[j].y;

//            if(currentx >= tempx-offset && currentx <= tempx+offset &&
//               currenty >= tempy-offset && currenty <= tempy+offset )
//            {
//                vector<Point> ::iterator iter = markedBoxes.begin() + j;
//                markedBoxes.erase(iter);
//                j--;
//                ++removals;
//            }
//        }
//    }

//    std::cout << "Total: " << boxCenters.size() << " Examined: " << boxCenters.size() - removals  << std::endl;

#if !defined DEBUG_BETMARKS
        //draw the detected marks
        for(int i=0;i<markedBoxes.size();i++)
            circle(imageOut,markedBoxes[i],8,Scalar(255,255,255),2);
        QString qsImageName = QString("lastMarkDetection");
        QString qsImageSequenceLocation = QDir::toNativeSeparators(QString("%1/%2/%3").arg(QDir::homePath ()).arg(QStringLiteral("AppData/Local/VirtualStore/")).arg (qsImageName));
        MatToQImage ( imageOut ).save(qsImageSequenceLocation,"JPG",100);

//        cv::namedWindow("Returned betmarks");
//        cv::imshow("Returned betmarks",imageOut);
//        waitKey();
#endif

    return markedBoxes;
}

Mat patternDetection::deskewImage(Mat &input/*, vector<vector<Point> > areas*/){

    double angle=0;
//  int Xa, Ya, Xb, Yb;

//  Xa = areas[0][0].x;
//  Ya = areas[0][0].y;
//  Xb = areas[0][1].x;
//  Yb = areas[0][1].y;

#ifdef DEBUG
    std::cout << "Xa: " << Xa << std::endl;
    std::cout << "Ya: " << Ya << std::endl;
    std::cout << "Xb: " << Xb << std::endl;
    std::cout << "Yb: " << Yb << std::endl;
#endif

    double temp = sqrt( abs(pow((Ya-Yb),2))  + abs(pow((Xa-Xb),2)) );
    std::cout << temp << std::endl;

    angle= (Ya-Yb) / sqrt( pow((Ya-Yb),2)  + pow((Xa-Xb),2) );

    std::cout << "Angle sine= " << angle << std::endl;
    if( (fabs(angle)) < 0.02 ){
        std::cout << "angle sine very small, skipping deskew" << std::endl;
        return input;
    }
    angle = asin(angle)* 180.0 / CV_PI;
    std::cout << "Skew angle = " << angle << std::endl;


    std::vector<cv::Point> points;
    cv::Mat_<uchar>::iterator it = input.begin<uchar>();
    cv::Mat_<uchar>::iterator end = input.end<uchar>();

    for (; it != end; ++it)
        if (*it)
            points.push_back(it.pos());

    cv::RotatedRect box = cv::minAreaRect(cv::Mat(points));
    cv::Mat rot_mat;
    if(logoDirection==RIGHT)
        rot_mat = cv::getRotationMatrix2D(box.center, angle, 1);
    if(logoDirection==LEFT)
        rot_mat = cv::getRotationMatrix2D(box.center, -angle, 1);

    cv::Mat rotated;
    cv::warpAffine(input, rotated, rot_mat, input.size(), cv::INTER_CUBIC);

#ifdef DEBUG_IMAGES
    cv::namedWindow("Deskewed Image");
    cv::imshow("Deskewed Image",rotated);
    waitKey();
#endif

    return rotated;
}

cv::Point2f patternDetection::computeIntersect(cv::Vec4i a, cv::Vec4i b)
{
    int x1 = a[0], y1 = a[1], x2 = a[2], y2 = a[3], x3 = b[0], y3 = b[1], x4 = b[2], y4 = b[3];

    if (float d = ((float)(x1 - x2) * (y3 - y4)) - ((y1 - y2) * (x3 - x4)))
    {
        cv::Point2f pt;
        pt.x = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / d;
        pt.y = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / d;
        return pt;
    }
    else
        return cv::Point2f(-1, -1);
}

void patternDetection::sortCorners(std::vector<cv::Point>& corners, cv::Point center)
{
    std::vector<cv::Point> top, bot;

    for (unsigned int i = 0; i < corners.size(); i++)
    {
        if (corners[i].y < center.y)
            top.push_back(corners[i]);
        else
            bot.push_back(corners[i]);
    }

    corners.clear();

    if (top.size() == 2 && bot.size() == 2){

        cv::Point tl = top[0].x > top[1].x ? top[1] : top[0];
        cv::Point tr = top[0].x > top[1].x ? top[0] : top[1];
        cv::Point bl = bot[0].x > bot[1].x ? bot[1] : bot[0];
        cv::Point br = bot[0].x > bot[1].x ? bot[0] : bot[1];


        corners.push_back(tl);
        corners.push_back(tr);
        corners.push_back(br);
        corners.push_back(bl);
    }
}

void patternDetection::blowMe(vector<Point> &corners)
{

    auto center(this->Center);

    // Get mass center
    for (unsigned int i = 0; i < corners.size(); i++)
        center += corners[i];

    center *= (1. / corners.size());

    sortCorners(corners, center);
    if (corners.size() == 0){
        std::cout << "The corners were not sorted correctly!" << std::endl;
        return ;
    }
}

Point patternDetection::detectCenters(vector<Point> &corners)
{

    auto center(this->Center);

    // Get mass center
    for (unsigned int i = 0; i < corners.size(); i++)
        center += corners[i];

    center *= (1. / corners.size());

    return center;
}

Mat patternDetection::splitChannels( const char *imagefile)
{
    Mat image;
    Mat channel[3];

    image = imread(imagefile, CV_LOAD_IMAGE_COLOR);
    if(image.data)
        split(image, channel);
    else
        std::cout << "Failed to load image from: " << imagefile << std::endl;

    return channel[2]; //red color removed
}

int patternDetection::Initialize()
{
    int readTickets = 0, loadRes;
    int fileCounter = 0;
    bool correctLoad = false;
    char fname[256];

    do
    {
          fileCounter++;
          readTickets++;

#ifdef WINDOWS
	  sprintf(fname,"coupon%02d.txt", fileCounter);
#else
	  sprintf(fname,"/home/mike/Dropbox/Programming/patternDetection/coupons/coupon%02d.txt", fileCounter);
#endif

	  loadRes=loadTickets(fname);
	  if(loadRes>=0)
	      correctLoad = true;

    }
    while (loadRes != -2); //loop until the file name is not found anymore

    if(correctLoad)
        return 0;

    std::cout << "Failed to load any tickets" << std::endl;
    return -1;
}

int patternDetection::loadTickets(const char *filename)
{
    FILE *fp;
    int linecount=1, readNums=0;
    int iTmp[2];
    char line[256], *check;
    char commentChar = '#';
    char betBoxes[] = "[BetBoxes]";
    Point tmpBox(0,0);

    fp = fopen(filename, "r");
    if (fp==NULL){
        std::cout << "Error opening ticket file: " << filename << std::endl;
        return -2;
    }

    while (((check = fgets(line, 256, fp)) != NULL) &&  (strncmp(line, betBoxes, strlen(betBoxes)) != 0)) linecount++;

    //Read all lines up to the end of file
    while ((check = fgets(line, 256, fp)) != NULL)
    {
        linecount++;

	//skip empty lines or comments
	if ((check[0] == commentChar) || (check[0] == '\n') || (check[0] == '\r'))
	    continue;


	readNums = sscanf(line, "%d %d", &iTmp[0], &iTmp[1]);

	if (readNums == 2)
	{
	    tmpBox.x = iTmp[0]*PIXEL2MM;
	    tmpBox.y = iTmp[1]*PIXEL2MM;
	    loadedBoxes.push_back(tmpBox);
	}
	else
	    std::cout << "Missing information at line, " << linecount << std::endl;


    }

    printf("Ticket %s loaded sucessfully - read %d marks\n", filename,loadedBoxes.size());

//    Mat image = imread("./lib/screenshot-075.jpg");
//    for (size_t i=0;i<loadedBoxes.size();i++){
//          std::cout << i << ". " << loadedBoxes[i].x << "-" << loadedBoxes[i].y << std::endl;
//          circle(image,loadedBoxes[i],1,Scalar(0,255,0),8);
//    }

//    imshow("Loaded boxes",image);
//    waitKey();

    fclose(fp);
    return 0;
}

//int patternDetection::perspectiveCorrection(cv::Mat &input)
//{

//    //convert to BW the input image
//    cv::Mat bw;
//    //cv::cvtColor(input, bw, CV_BGR2GRAY);
//    cv::blur(input, bw, cv::Size(3, 3));
//    cv::Canny(bw, bw, 100, 100, 3);

//    std::vector<cv::Vec4i> lines;
//    cv::HoughLinesP(bw, lines, 1, CV_PI/180, 70, 30, 10);

//    cv::imshow("HougLines", input);
//    cv::waitKey();

//    //Get the corners by finding intersections between lines
//    std::vector<cv::Point2f> corners;
//    for (unsigned int i = 0; i < lines.size(); i++)
//    {
//        for (unsigned int j = i+1; j < lines.size(); j++)
//        {
//            cv::Point2f pt = computeIntersect(lines[i], lines[j]);
//            if (pt.x >= 0 && pt.y >= 0)
//                    corners.push_back(pt);
//        }
//    }

//    std::vector<cv::Point2f> approx;
//    cv::approxPolyDP(cv::Mat(corners), approx, cv::arcLength(cv::Mat(corners), true) * 0.02, true);

//    if (approx.size() != 4)
//    {
//        std::cout << "The object is not quadrilateral! " << approx.size() << std::endl;
//        return -1;
//    }

//    // Get mass center
//    for (unsigned int i = 0; i < corners.size(); i++)
//        center += corners[i];

//    center *= (1. / corners.size());

//    sortCorners(corners, center);
//    if (corners.size() == 0){
//        std::cout << "The corners were not sorted correctly!" << std::endl;
//        return -1;
//    }
//    cv::Mat dst = input.clone();

//    // Draw lines
//    for (unsigned int i = 0; i < lines.size(); i++)
//    {
//        cv::Vec4i v = lines[i];
//        cv::line(dst, cv::Point(v[0], v[1]), cv::Point(v[2], v[3]), CV_RGB(0,255,0));
//    }

//    // Draw corner points
//    cv::circle(dst, corners[0], 3, CV_RGB(255,0,0), 2);
//    cv::circle(dst, corners[1], 3, CV_RGB(0,255,0), 2);
//    cv::circle(dst, corners[2], 3, CV_RGB(0,0,255), 2);
//    cv::circle(dst, corners[3], 3, CV_RGB(255,255,255), 2);

//    //draw mass center
//    cv::circle(dst, center, 3, CV_RGB(255,255,0), 2);
//    cv::Mat quad = cv::Mat::zeros(300, 220, CV_8UC3);

//    std::vector<cv::Point2f> quad_pts;
//    quad_pts.push_back(cv::Point2f(0, 0));
//    quad_pts.push_back(cv::Point2f(quad.cols, 0));
//    quad_pts.push_back(cv::Point2f(quad.cols, quad.rows));
//    quad_pts.push_back(cv::Point2f(0, quad.rows));

//    cv::Mat transmtx = cv::getPerspectiveTransform(corners, quad_pts);
//    cv::warpPerspective(input, quad, transmtx, quad.size());

//    cv::imshow("image", dst);
//    cv::imshow("quadrilateral", quad);
//    cv::waitKey();

//    return 0;

//}
