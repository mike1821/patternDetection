#ifndef PATTERNDETECTION_H
#define PATTERNDETECTION_H

#include <QString>
#include <QObject>
#include <QThread>
#include <QTimer>
#include <QMutex>
#include "definitions.h"

#include "opencv2/core/core.hpp"
#include "opencv2/features2d/features2d.hpp"
#include "opencv2/calib3d/calib3d.hpp"
#include "opencv2/highgui/highgui.hpp"

#include "opencv2/core/core.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"

using namespace std;
using namespace cv;

#ifdef WINDOWS
//#include "opencv2/xfeatures2d.hpp"
//#include "opencv2/xfeatures2d/nonfree.hpp"
#include "opencv2/nonfree/features2d.hpp"
#include "opencv2/nonfree/nonfree.hpp"
#include "opencv2/photo/photo.hpp"
#endif

class patternDetection : public QObject {
    Q_OBJECT


private:
    int thresh = 127, N = 1;
    int logoDirection;
    cv::Point2f square{0,0};
    float Xa,Xb,Ya,Yb;
    vector<Point> loadedBoxes;
    Point Fiducial;

    double calculateAngle( Point pt1, Point pt2, Point pt0 );
    cv::Point2f computeIntersect(cv::Vec4i a, cv::Vec4i b);
    void sortCorners(vector<Point>& corners, cv::Point center);
    void blowMe(vector<Point> &corners);
    Point detectCenters(vector<Point> &corners);
    bool compare(Point i, Point j);
    double distance (cv::Point i) {return sqrt( pow((i.x-Xa/*square.x*/),2)+pow((i.y-Ya/*square.y*/),2) );}

    vector<int> row;
    vector<int> col;
public:

    patternDetection();
    ~patternDetection();

    Mat img_object;
    //int processCoupon(Mat &input);
    int processCoupon( QString qsImage, int iIndex);
    const Point Center{0,0};
    vector<vector<Point> > detectAreas( Mat &image);
    vector<Point> detectBoxes( Mat &image, vector<vector<Point> > &RowsCols);
    vector<Point> interpolateBoxes( vector<Point> expectedCenters, vector<vector<Point> > foundBoxes);
    int detectLogo(Mat img_scene);
    vector<Point> ROIaveragePixelValue(cv::Mat &areaROI,  vector<Point> boxCenters, vector<vector<Point> > RowsCols);
    Mat deskewImage(Mat &input/*, vector<vector<Point> > areas*/);
    //int perspectiveCorrection(cv::Mat &input);
    void sortBoxes( vector<Point> &boxes);
    Mat splitChannels(const char *imagefile);
    int loadTickets(const char *filename);
    int Initialize();
};

#endif // PATTERNDETECTION_H

