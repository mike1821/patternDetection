#ifndef DEFINITIONS
#define DEFINITIONS

#define WINDOWS
//#define DEBUG_BETMARKS
//#define DEBUG_IMAGES
//#define DEEP_DEBUG
//#define DEBUG

#define IMG_HALF 640

//logo area limits
#define AREA_SIZE_TOLERANCE 15000
#define AREA_MIN_SIZE 5000
#define AREA_MAX_SIZE 200000

//bet boxes area limits
#define BOX_MIN_SIZE 200
#define BOX_MAX_SIZE 700

//fiducial area limits
#define FID_MIN_SIZE 600
#define FID_MAX_SIZE 1000

#define PIXEL2MM 0.471
#define UP    1
#define DOWN  2
#define LEFT  3
#define RIGHT 4

#endif // DEFINITIONS


