The redistribution of the Softek Barcode Reader DLL Files is strictly subject to license.

There are 3 approaches that can be taken to installation on a production system:

1.	Use a separate folder for the DLL files.
2.	Install the dll files into the windows system folders using the installers in this folder.
3.	Install a sub-set of the dll files into the same folder as the application

Each approach has its advantages, depending on the type of interface to be used, how the interfaces are used within the applications and whether or not 64-bit systems should be supported.

Note that the DLL files used in the installers in this folder are identical to the DLL files found in the x86 and x64 folders above. Use of these installers is entirely optional and it will often make more sense to install the DLL files along side the application in question (options 1 or 3).

Please see the documentation for further details; the section on Installation contains a useful discussion on the benefits of each approach and Appendix C contains useful information on file dependency.

The install sets in this folder will install the DLL files for the toolkit into the windows system folders on the target system and register all files requiring registration.

For complete details of redistribution please refer to the documentation. 

Important: On an x64 system where PDF files are to be processed please install both the x86 and x64 versions.

Use the /a flag to run the installer in automatic mode.
