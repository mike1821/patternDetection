#pragma once


namespace SampleBarcodeReader {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//

		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	internal: System::Windows::Forms::CheckBox^  CheckBitmap;
	protected: 
	internal: System::Windows::Forms::Label^  Label1;
	internal: System::Windows::Forms::Button^  Button1;
	internal: System::Windows::Forms::OpenFileDialog^  OpenFileDialog1;
	internal: System::Windows::Forms::TextBox^  Results;
	internal: System::Windows::Forms::TextBox^  ImageFile;
	internal: System::Windows::Forms::Button^  ReadBarcode;
	internal: System::Windows::Forms::Button^  ImageBtn;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->CheckBitmap = (gcnew System::Windows::Forms::CheckBox());
			this->Label1 = (gcnew System::Windows::Forms::Label());
			this->Button1 = (gcnew System::Windows::Forms::Button());
			this->OpenFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->Results = (gcnew System::Windows::Forms::TextBox());
			this->ImageFile = (gcnew System::Windows::Forms::TextBox());
			this->ReadBarcode = (gcnew System::Windows::Forms::Button());
			this->ImageBtn = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// CheckBitmap
			// 
			this->CheckBitmap->AutoSize = true;
			this->CheckBitmap->Location = System::Drawing::Point(10, 286);
			this->CheckBitmap->Name = L"CheckBitmap";
			this->CheckBitmap->Size = System::Drawing::Size(389, 17);
			this->CheckBitmap->TabIndex = 19;
			this->CheckBitmap->Text = L"Load page 1 of image into a Bitmap object and call ScanBarCodeFromBitmap";
			this->CheckBitmap->UseVisualStyleBackColor = true;
			this->CheckBitmap->CheckedChanged += gcnew System::EventHandler(this, &Form1::CheckBitmap_CheckedChanged);
			// 
			// Label1
			// 
			this->Label1->AutoSize = true;
			this->Label1->Location = System::Drawing::Point(10, 12);
			this->Label1->Name = L"Label1";
			this->Label1->Size = System::Drawing::Size(23, 13);
			this->Label1->TabIndex = 15;
			this->Label1->Text = L"File";
			this->Label1->Click += gcnew System::EventHandler(this, &Form1::Label1_Click);
			// 
			// Button1
			// 
			this->Button1->Location = System::Drawing::Point(360, 306);
			this->Button1->Name = L"Button1";
			this->Button1->Size = System::Drawing::Size(96, 23);
			this->Button1->TabIndex = 14;
			this->Button1->Text = L"Close";
			this->Button1->UseVisualStyleBackColor = true;
			this->Button1->Click += gcnew System::EventHandler(this, &Form1::Button1_Click);
			// 
			// OpenFileDialog1
			// 
			this->OpenFileDialog1->DefaultExt = L"tif";
			this->OpenFileDialog1->Filter = L"Images (*.tif,*.pdf,*.bmp,*.jpg)|*.tif;*.pdf;*.jpg;*.tiff;*.bmp;*.jpeg";
			this->OpenFileDialog1->FileOk += gcnew System::ComponentModel::CancelEventHandler(this, &Form1::OpenFileDialog1_FileOk);
			// 
			// Results
			// 
			this->Results->Location = System::Drawing::Point(10, 59);
			this->Results->Multiline = true;
			this->Results->Name = L"Results";
			this->Results->ReadOnly = true;
			this->Results->ScrollBars = System::Windows::Forms::ScrollBars::Vertical;
			this->Results->Size = System::Drawing::Size(569, 211);
			this->Results->TabIndex = 13;
			this->Results->TextChanged += gcnew System::EventHandler(this, &Form1::Results_TextChanged);
			// 
			// ImageFile
			// 
			this->ImageFile->Location = System::Drawing::Point(112, 12);
			this->ImageFile->Name = L"ImageFile";
			this->ImageFile->ReadOnly = true;
			this->ImageFile->Size = System::Drawing::Size(344, 20);
			this->ImageFile->TabIndex = 10;
			this->ImageFile->TextChanged += gcnew System::EventHandler(this, &Form1::ImageFile_TextChanged);
			// 
			// ReadBarcode
			// 
			this->ReadBarcode->Location = System::Drawing::Point(477, 306);
			this->ReadBarcode->Name = L"ReadBarcode";
			this->ReadBarcode->Size = System::Drawing::Size(102, 24);
			this->ReadBarcode->TabIndex = 12;
			this->ReadBarcode->Text = L"Read";
			this->ReadBarcode->Click += gcnew System::EventHandler(this, &Form1::ReadBarcode_Click);
			// 
			// ImageBtn
			// 
			this->ImageBtn->Location = System::Drawing::Point(477, 10);
			this->ImageBtn->Name = L"ImageBtn";
			this->ImageBtn->Size = System::Drawing::Size(102, 23);
			this->ImageBtn->TabIndex = 11;
			this->ImageBtn->Text = L"Browse";
			this->ImageBtn->Click += gcnew System::EventHandler(this, &Form1::ImageBtn_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(590, 341);
			this->Controls->Add(this->CheckBitmap);
			this->Controls->Add(this->Label1);
			this->Controls->Add(this->Button1);
			this->Controls->Add(this->Results);
			this->Controls->Add(this->ImageFile);
			this->Controls->Add(this->ReadBarcode);
			this->Controls->Add(this->ImageBtn);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

private: System::Void ReadBarcode_Click(System::Object^  sender, System::EventArgs^  e) {
		SoftekBarcodeLib3::BarcodeReader ^barcode ;

		Results->Text = "" ;

        // For the purposes of this demo we first give a path to the installation folder
        // and the class adds either x86 or x64 to the end and tries to load the other dll files.
        // If that fails (perhaps this project has been moved) then we give no path and the class
        // assumes that the dll files will be somewhere on the PATH.
        try
        {
			barcode = gcnew SoftekBarcodeLib3::BarcodeReader("..\\..\\..");
        }
		catch (System::DllNotFoundException ^ex)
        {
			barcode = gcnew SoftekBarcodeLib3::BarcodeReader();
        }

        // Enter your license key here
        // You can get a trial license key from sales@bardecode.com
        // Example:
        // barcode->LicenseKey = "MY LICENSE KEY";

        // Turn on the barcode types you want to read.
        // Turn off the barcode types you don't want to read (this will increase the speed of your application)
        barcode->ReadCode128 = true ;
        barcode->ReadCode39 = true ;
        barcode->ReadCode25 = true ;
        barcode->ReadEAN13 = true ;
        barcode->ReadEAN8 = true ;
        barcode->ReadUPCA = true ;
        barcode->ReadUPCE = true ;
        barcode->ReadCodabar = false ;
        barcode->ReadPDF417 = false ;
		barcode->ReadDataMatrix = false ;
        barcode->ReadDatabar = false;
        barcode->ReadMicroPDF417 = false;
		barcode->ReadQRCode = false;

        // Databar Options is a mask that controls which type of databar barcodes will be read and whether or not
        // the software will look for a quiet zone around the barcode.
        // 1 = 2D-Linkage flag (handle micro-PDf417 barcodes as supplementary data - requires ReadMicroPDF417 to be true).
        // 2 = Read RSS14
        // 4 = Read RSS14 Stacked
        // 8 = Read Limited
        // 16 = Read Expanded
        // 32 = Read Expanded Stacked
        // 64 = Require quiet zone
        barcode->DatabarOptions = 255;

        // If you want to read more than one barcode then set Multiple Read to 1
        // Setting MutlipleRead to False will make the recognition faster
        barcode->MultipleRead = true ;

        // Noise reduction takes longer but can make it possible to read some difficult barcodes
        // When using noise reduction a typical value is 10 - the smaller the value the more effect it has.
        // A zero value turns off noise reduction.
        // barcode->NoiseReduction = 0 ;

        // You may need to set a small quiet zone if your barcodes are close to text and pictures in the image.
        // A value of zero uses the default.
        barcode->QuietZoneSize = 0 ;

        // LineJump controls the frequency at which scan lines in an image are sampled.
        // The default is 1.
        barcode->LineJump = 1 ;

        // You can restrict your search to a particular area of the image if you wish.
        // In this example the scan area is restricted to the top half of the page
		// System::Drawing::Rectangle *scanArea = new System::Drawing::Rectangle(0, 0, 100, 50);
		// barcode->SetScanRect(*scanArea, 1);

        // Set the direction that the barcode reader should scan for barcodes
        // The value is a mask where 1 = Left to Right, 2 = Top to Bottom, 3 = Right To Left, 4 = Bottom to Top
        barcode->ScanDirection = 15 ;

        // Set the page number to read from in a multi-page TIF file. The default is 0, which will make the
        // toolkit check every page.
        // barcode->PageNo = 1 ;

        // SkewTolerance controls the angle of skew that the barcode toolkit will tolerate. By default
        // the toolkit checks for barcodes along horizontal and vertical lines in an image. This works
        // OK for most barcodes because even at an angle it is possible to pass a line through the entire
        // length. SkewTolerance can range from 0 to 5 and allows for barcodes skewed to an angle of 45
        // degrees.
        barcode->SkewTolerance = 0 ;

        // ColorProcessingLevel controls how much time the toolkit will searching a color image for a barcode.
        // The default value is 2 and the range of values is 0 to 5. If ColorThreshold is non-zero then 
        // ColorProcessingLevel is effectively set to 0.
        barcode->ColorProcessingLevel = 2;

        // MaxLength and MinLength can be used to specify the number of characters you expect to
        // find in a barcode. This can be useful to increase accuracy or if you wish to ignore some
        // barcodes in an image.
        barcode->MinLength = 4 ;
        barcode->MaxLength = 999 ;

        // When the toolkit scans an image it records the number of hits it gets for each barcode that
        // MIGHT be in the image. If the hits recorded for any of the barcodes are >= PrefOccurrence
        // then only these barcodes are returned. Otherwise, any barcode whose hits are >= MinOccurrence
        // are reported. If you have a very poor quality image then try setting MinOccurrence to 1, but you
        // may find that some false positive results are returned.
        //barcode->MinOccurrence = 2 ;
        //barcode->PrefOccurrence = 4 ;

        // Read Code 39 barcodes in extended mode
        // barcode->ExtendedCode39 = true ;

        // Barcode string is numeric
        // barcode.ReadNumeric = true ;

        // Set a regular expression for the barcode
        // barcode->Pattern = "^[A-Z]{2}[0-9]{5}$" ;

        // If you are scanning at a high resolution and the spaces between bars are
        // larger than 1 pixel then set MinSpaceBarWidth to 2 and increase your read rate.
        // barcode->MinSpaceBarWidth = 2 ;

        // MedianFilter is a useful way to clean up higher resolution images where the black bars contain white dots
        // and the spaces contain black dots. It does not work if the space between bars is only 1 pixel wide.
        barcode->MedianFilter = false ;	

        // Flags for handling PDF files
        // PdfImageOnly defaults to true and indicates that the PDF documents are simple images.
        barcode->PdfImageOnly = true;

        // The PdfImageExtractOptions mask controls how images are removed from PDF documents (when PdfImageOnly is True)
        // 1 = Enable fast extraction
        // 2 = Auto-invert black and white images
        // 4 = Auto-merge strips
        // 8 = Auto-correct photometric values in black and white images
        barcode->PdfImageExtractOptions = 15 ;

        // The PdfImageRasterOptions mask controls how images are rasterized when PdfImageOnly is false or when image extraction fails
        // 1 = Use alternative pdf-to-tif conversion function
        // 2 = Always use pdf-to-tif conversion rather than loading the rasterized image directly into memory
        barcode->PdfImageRasterOptions = 0 ;

        // PdfDpi and PdfBpp control what sort of image the PDF document is rasterized into
        barcode->PdfDpi = 300 ;
        barcode->PdfBpp = 8 ; 

		int nBarCodes ;
		if (CheckBitmap->Checked) {
			Results->Text += "Loading image into a bitmap and calling ScanBarCodeFromBitmap\r\n" ;
			System::Drawing::Bitmap ^bm = gcnew System::Drawing::Bitmap(ImageFile->Text) ;
			nBarCodes = barcode->ScanBarCodeFromBitmap(bm) ;
			bm->~Bitmap() ;
		} else {
			nBarCodes = barcode->ScanBarCode(ImageFile->Text) ;
		}

		if (nBarCodes <= -6)
		{
			Results->Text += "License key error: either an evaluation key has expired or the license key is not valid for processing pdf documents" ;
		}
		else if (nBarCodes < 0)
		{
			Results->Text += String::Format("ScanBarCode returned error number {0}\r\n", nBarCodes) ;
			Results->Text += String::Format("Last Softek Error Number =  {0}\r\n", barcode->GetLastError()) ;
			Results->Text += String::Format("Last Windows Error Number =  {0}\r\n", barcode->GetLastWinError()) ;
		}
		else if (nBarCodes == 0)
		{
			Results->Text = "No barcode found on this image" ;
		}
		else
		{
			for (int i = 1; i <= nBarCodes; i++) {
				Results->Text += String::Format("Barcode {0}:\r\n", i) ;
				Results->Text += String::Format("Value = {0}\r\n", barcode->GetBarString(i)) ;
				Results->Text += String::Format("Type = {0}\r\n", barcode->GetBarStringType(i)) ;

				Results->Text += "Direction = " ;
				switch (barcode->GetBarStringDirection(i))
				{
				case 1:
					Results->Text += "Left to Right" ;
					break ;
				case 2:
					Results->Text += "Top to Bottom" ;
					break ;
				case 4:
					Results->Text += "Right to Left" ;
					break ;
				case 8:
					Results->Text += "Bottom to Top" ;
					break ;
				}
				Results->Text += "\r\n" ;

				Results->Text += String::Format("Page = {0}\r\n", barcode->GetBarStringPage(i)) ;
				System::Drawing::Rectangle rect = barcode->GetBarStringRect(i) ;
				Results->Text += String::Format("Top Left = ({0},{1})\r\n", rect.X, rect.Y) ;
				Results->Text += String::Format("Bottom Right = ({0},{1})\r\n\r\n", rect.X + rect.Width, rect.Y + rect.Height) ;
			}
		}
		barcode->~BarcodeReader() ;

	}
private: System::Void ImageBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			OpenFileDialog1->ShowDialog() ;
			ImageFile->Text = OpenFileDialog1->FileName ;
		 }
private: System::Void Button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->Close() ;
		 }
private: System::Void Label1_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void OpenFileDialog1_FileOk(System::Object^  sender, System::ComponentModel::CancelEventArgs^  e) {
		 }
private: System::Void Results_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void ImageFile_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void CheckBitmap_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}

