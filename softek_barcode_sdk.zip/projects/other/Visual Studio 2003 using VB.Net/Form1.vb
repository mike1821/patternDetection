Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents ImageBtn As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ReadBarcode As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ImageFile As System.Windows.Forms.TextBox
    Friend WithEvents Results As System.Windows.Forms.TextBox
    Friend WithEvents CheckBitmap As System.Windows.Forms.CheckBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.ImageFile = New System.Windows.Forms.TextBox
        Me.ImageBtn = New System.Windows.Forms.Button
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.Results = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.ReadBarcode = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.CheckBitmap = New System.Windows.Forms.CheckBox
        Me.SuspendLayout()
        '
        'ImageFile
        '
        Me.ImageFile.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ImageFile.Location = New System.Drawing.Point(72, 16)
        Me.ImageFile.Name = "ImageFile"
        Me.ImageFile.ReadOnly = True
        Me.ImageFile.Size = New System.Drawing.Size(352, 20)
        Me.ImageFile.TabIndex = 0
        Me.ImageFile.Text = ""
        '
        'ImageBtn
        '
        Me.ImageBtn.Location = New System.Drawing.Point(440, 16)
        Me.ImageBtn.Name = "ImageBtn"
        Me.ImageBtn.Size = New System.Drawing.Size(96, 24)
        Me.ImageBtn.TabIndex = 1
        Me.ImageBtn.Text = "Browse"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.DefaultExt = "tif"
        Me.OpenFileDialog1.Filter = "Images (*.tif,*.bmp,*.jpg)|*.tif;*.jpg;*.tiff;*.bmp;*.jpeg"
        '
        'Results
        '
        Me.Results.Location = New System.Drawing.Point(8, 72)
        Me.Results.Multiline = True
        Me.Results.Name = "Results"
        Me.Results.ReadOnly = True
        Me.Results.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Results.Size = New System.Drawing.Size(528, 208)
        Me.Results.TabIndex = 3
        Me.Results.Text = ""
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 16)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "File"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(8, 48)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 24)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Results"
        '
        'ReadBarcode
        '
        Me.ReadBarcode.Location = New System.Drawing.Point(440, 320)
        Me.ReadBarcode.Name = "ReadBarcode"
        Me.ReadBarcode.Size = New System.Drawing.Size(96, 24)
        Me.ReadBarcode.TabIndex = 2
        Me.ReadBarcode.Text = "Read"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(328, 320)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(96, 24)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "Close"
        '
        'CheckBitmap
        '
        Me.CheckBitmap.Location = New System.Drawing.Point(8, 288)
        Me.CheckBitmap.Name = "CheckBitmap"
        Me.CheckBitmap.Size = New System.Drawing.Size(520, 24)
        Me.CheckBitmap.TabIndex = 15
        Me.CheckBitmap.Text = "Load page 1 of image into a Bitmap object and call ScanBarCodeFromBitmap"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(544, 356)
        Me.Controls.Add(Me.CheckBitmap)
        Me.Controls.Add(Me.ImageFile)
        Me.Controls.Add(Me.Results)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.ImageBtn)
        Me.Controls.Add(Me.ReadBarcode)
        Me.Name = "Form1"
        Me.Text = "Barcode Reader"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ImageBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImageBtn.Click
        OpenFileDialog1.ShowDialog()
        ImageFile.Text = OpenFileDialog1.FileName
    End Sub
    Private Sub ReadMAN()
        Dim nBarCodes As Integer
        Dim Path As String
        Dim i As Integer
        Dim nDirection As Integer
        Dim nPage As Integer
        Dim rect As System.Drawing.Rectangle
        Dim barcode As SoftekBarcodeLib.BarcodeReader

        barcode = New SoftekBarcodeLib.BarcodeReader

        ' Enter your license key here
        ' You can get a trial license key from sales@bardecode.com
        ' Example:
        ' barcode.LicenseKey = "MY LICENSE KEY"

        ' Turn on the barcode types you want to read.
        ' Turn off the barcode types you don't want to read (this will increase the speed of your application)
        barcode.ReadCode128 = True
        barcode.ReadCode39 = True
        barcode.ReadCode25 = True
        barcode.ReadEAN13 = True
        barcode.ReadEAN8 = True
        barcode.ReadUPCA = True
        barcode.ReadUPCE = True
        barcode.ReadCodabar = False
        barcode.ReadPDF417 = True
        barcode.ReadDataMatrix = False
        barcode.ReadDatabar = False
        barcode.ReadMicroPDF417 = False

        ' Databar Options is a mask that controls which type of databar barcodes will be read and whether or not
        ' the software will look for a quiet zone around the barcode.
        ' 1 = 2D-Linkage flag (handle micro-PDf417 barcodes as supplementary data - requires ReadMicroPDF417 to be true).
        ' 2 = Read RSS14
        ' 4 = Read RSS14 Stacked
        ' 8 = Read Limited
        ' 16 = Read Expanded
        ' 32 = Read Expanded Stacked
        ' 64 = Require quiet zone
        barcode.DatabarOptions = 255

        ' If you want to read more than one barcode then set Multiple Read to 1
        ' Setting MutlipleRead to False will make the recognition faster
        barcode.MultipleRead = True

        ' Noise reduction takes longer but can make it possible to read some difficult barcodes
        ' When using noise reduction a typical value is 10 - the smaller the value the more effect it has.
        ' A zero value turns off noise reduction.
        ' If you use NoiseReduction then the ScanDirection mask must be either only horizontal or only
        ' vertical (i.e 1, 2, 4, 8, 5 or 10).
        ' barcode.NoiseReduction = 0

        ' You may need to set a small quiet zone if your barcodes are close to text and pictures in the image.
        ' A value of zero uses the default.
        barcode.QuietZoneSize = 0

        ' LineJump controls the frequency at which scan lines in an image are sampled.
        ' The default is 1.
        barcode.LineJump = 1

        ' You can restrict your search to a particular area of the image if you wish.
        ' retval = barcode.SetScanRect(TopLeftX, TopLeftY, BottomRightX, BottomRightY, 0)

        ' Set the direction that the barcode reader should scan for barcodes
        ' The value is a mask where 1 = Left to Right, 2 = Top to Bottom, 3 = Right To Left, 4 = Bottom to Top
        barcode.ScanDirection = 15

        ' Set the page number to read from in a multi-page TIF file. The default is 0, which will make the
        ' toolkit check every page.
        ' barcode.PageNo = 1

        ' SkewTolerance controls the angle of skew that the barcode toolkit will tolerate. By default
        ' the toolkit checks for barcodes along horizontal and vertical lines in an image. This works
        ' OK for most barcodes because even at an angle it is possible to pass a line through the entire
        ' length. SkewTolerance can range from 0 to 5 and allows for barcodes skewed to an angle of 45
        ' degrees.
        barcode.SkewTolerance = 0

        ' ColorProcessingLevel controls how much time the toolkit will searching a color image for a barcode.
        ' The default value is 2 and the range of values is 0 to 5. If ColorThreshold is non-zero then 
        ' ColorProcessingLevel is effectively set to 0.
        barcode.ColorProcessingLevel = 2

        ' MaxLength and MinLength can be used to specify the number of characters you expect to
        ' find in a barcode. This can be useful to increase accuracy or if you wish to ignore some
        ' barcodes in an image.
        barcode.MinLength = 4
        barcode.MaxLength = 999

        ' When the toolkit scans an image it records the number of hits it gets for each barcode that
        ' MIGHT be in the image. If the hits recorded for any of the barcodes are >= PrefOccurrence
        ' then only these barcodes are returned. Otherwise, any barcode whose hits are >= MinOccurrence
        ' are reported. If you have a very poor quality image then try setting MinOccurrence to 1, but you
        ' may find that some false positive results are returned.
        'barcode.MinOccurrence = 2
        'barcode.PrefOccurrence = 4

        ' Read Code 39 barcodes in extended mode
        ' barcode.ExtendedCode39 = True

        ' Barcode string is numeric
        ' barcode.ReadNumeric = True

        ' Set a regular expression for the barcode
        ' barcode.Pattern = "^[A-Z]{2}[0-9]{5}$"

        ' If you are scanning at a high resolution and the spaces between bars are
        ' larger than 1 pixel then set MinSpaceBarWidth to 2 and increase your read rate.
        ' barcode.MinSpaceBarWidth = 2

        ' MedianFilter is a useful way to clean up higher resolution images where the black bars contain white dots
        ' and the spaces contain black dots. It does not work if the space between bars is only 1 pixel wide.
        barcode.MedianFilter = False

        Path = ImageFile.Text

        Results.Text = ""

        WriteResult("Using Managed Class Interface to read barcodes")

        If CheckBitmap.Checked Then
            Dim bm As Bitmap
            WriteResult("Loading image into a bitmap and calling ScanBarCodeFromBitmap")
            bm = New Bitmap(Path)
            nBarCodes = barcode.ScanBarCodeFromBitmap(bm)
        Else
            nBarCodes = barcode.ScanBarCode(Path)
        End If

        If nBarCodes < 0 Then
            WriteResult("ScanBarCode returned error number " & nBarCodes)
        End If

        If nBarCodes = 0 Then
            WriteResult("Sorry - no barcodes were found in this image")
        End If

        For i = 1 To nBarCodes
            WriteResult("")
            WriteResult("Barcode " & i & ":")

            WriteResult("Value = " & barcode.GetBarString(i))

            WriteResult("Type = " & barcode.GetBarStringType(i))

            nDirection = barcode.GetBarStringDirection(i)
            If nDirection = 1 Then
                WriteResult("Direction = Left to Right")
            Else
                If nDirection = 2 Then
                    WriteResult("Direction = Top to Bottom")
                Else
                    If nDirection = 4 Then
                        WriteResult("Direction = Right to Left")
                    Else
                        If nDirection = 8 Then
                            WriteResult("Direction = Bottom to Top")
                        End If
                    End If
                End If
            End If

            nPage = barcode.GetBarStringPage(i)
            rect = barcode.GetBarStringRect(i)
            WriteResult("Page = " & nPage)
            WriteResult("Top Left = (" & rect.X & "," & rect.Y & ")")
            WriteResult("Bottom Right = (" & (rect.X + rect.Width) & "," & (rect.Y + rect.Height) & ")")

        Next i

        GC.Collect()
    End Sub

    Private Sub ReadBarcode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReadBarcode.Click
        ReadMAN()
    End Sub

    Private Sub ReadBarCodeFromPicture_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Sub WriteResult(ByVal Result As String)
        With Results
            Results.Text += Result + vbNewLine
        End With
    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub FilePath_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImageFile.TextChanged

    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Result_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Results.TextChanged

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Panel2_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs)

    End Sub

    Private Sub ResultFromPicture_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs)

    End Sub

    Private Sub OpenFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk

    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        End
    End Sub
End Class


